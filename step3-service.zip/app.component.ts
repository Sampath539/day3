import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template: `
  <app-header [heroes]="data"></app-header>
  <hr>
  <app-grid [heroes]="data"></app-grid>
  `
})
export class AppComponent {
  data = [];
  constructor(private hs: HeroService){
    this.data = hs.getHeroes();
  }
}
