import { Component, Input } from '@angular/core';

@Component({
  selector : 'app-header',
  template : `
  <!--li *ngFor='let hero of data'>{{ hero | json }}</li-->
  <ul class="nav navbar-nav">
    <li *ngFor='let hero of heroes'>
      <a href="/{{ hero.title }}">{{ hero.title }}</a>
    </li>
  </ul>
  `
})
export class HeaderComponent{
  @Input() heroes = [];
}
