import { Component, Input } from "@angular/core";

@Component({
  selector : 'app-grid',
  template : `
  <table class='table table-striped table-responsive'>
  <thead>
    <tr>
      <th>SL #</th>
      <th>Title</th>
      <th>Full Name</th>
      <th>Photo</th>
      <th>City</th>
      <th>Ticket Price</th>
      <th>Release Date</th>
      <th>Movies Count</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor='let hero of heroes'>
      <td>{{ hero.sl }}</td>
      <td>{{ hero.title | uppercase }}</td>
      <td>{{ hero.firstname+' '+hero.lastname }}</td>
      <td><img class='img img-circle' src="{{ hero.poster }}" alt="{{ hero.title }}" width='50'></td>
      <td>{{ hero.city }}</td>
      <td>{{ hero.ticketprice | currency:'INR': 'symbol' : '3.2-3'  }}</td>
      <td>{{ hero.releasedate | date : 'dd / MMM / yyyy' | lowercase | uppercase }}</td>
      <td>{{ hero.movieslist.length }}</td>
    </tr>
  </tbody>
</table>
  `
})
export class GridComponent{
  @Input() heroes = [];
}
