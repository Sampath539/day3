import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GenPipe } from './gen.pipe';
import { IBMDirective } from './ibm.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [GenPipe, IBMDirective],
  declarations: [GenPipe, IBMDirective]
})
export class IbmModule { }
