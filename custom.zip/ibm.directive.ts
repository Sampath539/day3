import { Directive, OnInit, ElementRef, Input } from "@angular/core";

@Directive({
    selector : '[appIbm]'
})
export class IBMDirective implements OnInit {
    // STEP 2
    @Input() appIbm;
    constructor(private er: ElementRef){ }
    ngOnInit(){
       /* STEP 1

       this.er.nativeElement.innerHTML = 'Changed by Directive';
      */

        /* STEP 2
        */
        this.er.nativeElement.style.border = '2px solid '+this.appIbm;

       /* STEP 3
       */
       this.er.nativeElement.addEventListener("click", ()=>{
           this.er.nativeElement.innerHTML = 'Clicked'
        })
    }
}
