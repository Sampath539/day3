import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name : 'ibmgen'
})
export class GenderPipe implements PipeTransform{

  transform(arg1, arg2, arg3){
    if(arg2 === 'male'){
      return "Mr. "+arg1+" from "+arg3;
    }else{
      return "Mrs. "+arg1+" from "+arg3;
    }
  }

}
