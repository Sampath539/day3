import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform {
    transform(val, gender ) {
        if (gender === 'male') {
            return ' Mr. ' + val;
        } else {
            return ' Mrs. ' + val;
        }
    }
}
